// --- Utilities ---
  const $ = sel => document.querySelector(sel);
  const $$ = sel => Array.from(document.querySelectorAll(sel));
  const dbKey = k => "mbs_" + k;
  const load = (k, d=[]) => { try{ return JSON.parse(localStorage.getItem(dbKey(k))||"null") ?? d }catch(e){ return d } };
  const save = (k, v) => localStorage.setItem(dbKey(k), JSON.stringify(v));
  const fmt = new Intl.NumberFormat('en-US',{style:'currency',currency:'USD'});
  const todayISO = () => new Date().toISOString().slice(0,10);
  const parseDT = v => v ? new Date(v) : null;

  // --- Data ---
  let Clients = load('clients');
  let Techs = load('techs');
  let Services = load('services');
  let WorkOrders = load('work_orders');
  let Deposits = load('deposits');
  let Availability = load('availability');
  let Inventory = load('inventory');

  function persistAll(){
    save('clients', Clients);
    save('techs', Techs);
    save('services', Services);
    save('work_orders', WorkOrders);
    save('deposits', Deposits);
    save('availability', Availability);
    save('inventory', Inventory);
  }

  // Seed sample services if empty
  if(Services.length===0){
    Services = [
      {ServiceID:'S-1001', Name:'TV Mounting', Category:'Assembly', BasePrice:90, EstimatedHours:1.5, Description:'Single TV up to 65"' },
      {ServiceID:'S-1002', Name:'Dresser Assembly', Category:'Assembly', BasePrice:100, EstimatedHours:2, Description:'6-drawer dresser' },
      {ServiceID:'S-2001', Name:'Full Service & Repairs', Category:'Repairs', BasePrice:0, EstimatedHours:'', Description:'Scope-based' }
    ];
  }
  persistAll();

  // --- Navigation ---
  const sections = ['dashboard','workorders','clients','techs','services','deposits','inventory','settings'];
  $$('.footer-nav .btn').forEach(b=>{
    b.addEventListener('click',()=>showSection(b.dataset.nav));
  });
  function showSection(id){
    sections.forEach(s=>{
      const el = $('#'+s);
      if(!el) return;
      el.classList.toggle('active', s===id);
    });
    $$('.footer-nav .btn').forEach(b=> b.setAttribute('aria-current', b.dataset.nav===id ? 'page' : 'false'));
    if(id==='dashboard') renderDashboard();
    if(id==='workorders') renderWO();
    if(id==='clients') renderClients();
    if(id==='techs') { renderTechs(); renderAvailability(); }
    if(id==='services') renderServices();
    if(id==='deposits') renderDeposits();
    if(id==='inventory') renderInventory();
  }

  // --- Dashboard ---
  function renderDashboard(){
    const today = todayISO();
    const jobs = WorkOrders.filter(w=> (w.ScheduledStart||'').slice(0,10)===today);
    $('#todaySummary').textContent = jobs.length ? `${jobs.length} job(s) today` : 'No jobs scheduled today';
    const list = $('#todayJobs'); list.innerHTML='';
    jobs.sort((a,b)=>(a.ScheduledStart||'').localeCompare(b.ScheduledStart||''));
    jobs.forEach(w=>{
      const it = renderItem(`${w.WorkOrderID} — ${w.ServiceID||''} • ${w.ClientID||''}`,
        [ badge(w.Status), btn('Open', ()=>{ fillWOForm(w); showSection('workorders'); }) ]
      );
      list.appendChild(it);
    });
  }

  // --- Helpers UI ---
  function badge(t){
    const span = document.createElement('span'); span.className='pill';
    span.textContent=t;
    if(t==='Completed') span.classList.add('ok');
    if(t==='Scheduled'||t==='In Progress') span.classList.add('warn');
    if(t==='Canceled') span.classList.add('bad');
    return span;
  }
  function btn(txt, fn, cls='btn small'){
    const b = document.createElement('button'); b.className=cls; b.textContent=txt; b.addEventListener('click', fn); return b;
  }
  function renderItem(text, right=[]){
    const t = document.getElementById('tpl-item');
    const node = t.content.firstElementChild.cloneNode(true);
    node.querySelector('.text').textContent = text;
    const r = node.querySelector('.right'); right.forEach(x=>r.appendChild(x));
    return node;
  }

  // --- Clients ---
  function renderClients(){
    const list = $('#clList'); list.innerHTML='';
    Clients.forEach(c=>{
      list.appendChild(renderItem(`${c.ClientID} — ${c.FirstName||''} ${c.LastName||''} (${c.Phone||''})`, [
        btn('Use', ()=>{ $('#woClient').value = c.ClientID; showSection('workorders'); }),
        btn('Edit', ()=>fillClientForm(c))
      ]));
    });
    updateSelectors();
  }
  function fillClientForm(c){
    $('#clId').value=c.ClientID||'';
    $('#clPhone').value=c.Phone||'';
    $('#clFirst').value=c.FirstName||'';
    $('#clLast').value=c.LastName||'';
    $('#clEmail').value=c.Email||'';
    $('#clAddr').value=c.Address||'';
  }
  $('#clientForm').addEventListener('submit', e=>{
    e.preventDefault();
    const c = {
      ClientID: $('#clId').value.trim(),
      Phone: $('#clPhone').value.trim(),
      FirstName: $('#clFirst').value.trim(),
      LastName: $('#clLast').value.trim(),
      Email: $('#clEmail').value.trim(),
      Address: $('#clAddr').value.trim()
    };
    const i = Clients.findIndex(x=>x.ClientID===c.ClientID);
    if(i>=0) Clients[i]=c; else Clients.push(c);
    persistAll(); renderClients(); e.target.reset();
  });
  $('#clClear').addEventListener('click', ()=>$('#clientForm').reset());
  $('#clDelete').addEventListener('click', ()=>{
    const id = $('#clId').value.trim();
    if(!id) return;
    Clients = Clients.filter(x=>x.ClientID!==id);
    persistAll(); renderClients(); $('#clientForm').reset();
  });

  // --- Techs & Availability ---
  function renderTechs(){
    const list = $('#tList'); list.innerHTML='';
    Techs.forEach(tk=>{
      list.appendChild(renderItem(`${tk.TechID} — ${tk.FirstName||''} ${tk.LastName||''} (${tk.Region||''})`, [
        btn('Use', ()=>{ $('#woTech').value = tk.TechID; showSection('workorders'); }),
        btn('Edit', ()=>fillTechForm(tk))
      ]));
    });
    updateSelectors();
  }
  function fillTechForm(tk){
    $('#tId').value=tk.TechID||'';
    $('#tPhone').value=tk.Phone||'';
    $('#tFirst').value=tk.FirstName||'';
    $('#tLast').value=tk.LastName||'';
    $('#tEmail').value=tk.Email||'';
    $('#tRegion').value=tk.Region||'';
  }
  $('#techForm').addEventListener('submit', e=>{
    e.preventDefault();
    const tk = {
      TechID: $('#tId').value.trim(),
      Phone: $('#tPhone').value.trim(),
      FirstName: $('#tFirst').value.trim(),
      LastName: $('#tLast').value.trim(),
      Email: $('#tEmail').value.trim(),
      Region: $('#tRegion').value.trim()
    };
    const i = Techs.findIndex(x=>x.TechID===tk.TechID);
    if(i>=0) Techs[i]=tk; else Techs.push(tk);
    persistAll(); renderTechs(); e.target.reset();
  });
  $('#tClear').addEventListener('click', ()=>$('#techForm').reset());
  $('#tDelete').addEventListener('click', ()=>{
    const id = $('#tId').value.trim();
    if(!id) return;
    Techs = Techs.filter(x=>x.TechID!==id);
    persistAll(); renderTechs(); $('#techForm').reset();
  });

  // Availability
  function renderAvailability(){
    const list = $('#avList'); list.innerHTML='';
    Availability.forEach(a=>{
      const txt = `${a.TechID} — ${a.Date} ${a.StartTime}-${a.EndTime} • ${a.IsAvailable?'Available':'Blocked'}`;
      list.appendChild(renderItem(txt, [btn('Edit', ()=>fillAvForm(a))]));
    });
    updateSelectors();
  }
  function fillAvForm(a){
    $('#avTech').value=a.TechID||'';
    $('#avDate').value=a.Date||'';
    $('#avStart').value=a.StartTime||'';
    $('#avEnd').value=a.EndTime||'';
    $('#avIs').value=String(!!a.IsAvailable);
    $('#avNotes').value=a.Notes||'';
  }
  $('#avForm').addEventListener('submit', e=>{
    e.preventDefault();
    const a = {
      TechID: $('#avTech').value,
      Date: $('#avDate').value,
      StartTime: $('#avStart').value,
      EndTime: $('#avEnd').value,
      IsAvailable: $('#avIs').value==='true',
      Notes: $('#avNotes').value.trim()
    };
    const i = Availability.findIndex(x=>x.TechID===a.TechID && x.Date===a.Date && x.StartTime===a.StartTime);
    if(i>=0) Availability[i]=a; else Availability.push(a);
    persistAll(); renderAvailability(); e.target.reset();
  });
  $('#avClear').addEventListener('click', ()=>$('#avForm').reset());
  $('#avDelete').addEventListener('click', ()=>{
    const key = {TechID:$('#avTech').value, Date:$('#avDate').value, StartTime:$('#avStart').value};
    Availability = Availability.filter(x=> !(x.TechID===key.TechID && x.Date===key.Date && x.StartTime===key.StartTime));
    persistAll(); renderAvailability(); $('#avForm').reset();
  });

  // --- Services ---
  function renderServices(){
    const list = $('#sList'); list.innerHTML='';
    Services.forEach(s=>{
      list.appendChild(renderItem(`${s.ServiceID} — ${s.Name} • ${s.Category} • ${fmt.format(Number(s.BasePrice||0))}`, [
        btn('Use', ()=>{ $('#woService').value = s.ServiceID; showSection('workorders'); }),
        btn('Edit', ()=>fillServiceForm(s))
      ]));
    });
    updateSelectors();
  }
  function fillServiceForm(s){
    $('#sId').value=s.ServiceID||'';
    $('#sCat').value=s.Category||'';
    $('#sName').value=s.Name||'';
    $('#sPrice').value=s.BasePrice||'';
    $('#sHours').value=s.EstimatedHours||'';
    $('#sDesc').value=s.Description||'';
  }
  $('#svcForm').addEventListener('submit', e=>{
    e.preventDefault();
    const s = {
      ServiceID: $('#sId').value.trim(),
      Category: $('#sCat').value.trim(),
      Name: $('#sName').value.trim(),
      BasePrice: Number($('#sPrice').value||0),
      EstimatedHours: $('#sHours').value,
      Description: $('#sDesc').value.trim()
    };
    const i = Services.findIndex(x=>x.ServiceID===s.ServiceID);
    if(i>=0) Services[i]=s; else Services.push(s);
    persistAll(); renderServices(); e.target.reset();
  });
  $('#sClear').addEventListener('click', ()=>$('#svcForm').reset());
  $('#sDelete').addEventListener('click', ()=>{
    const id = $('#sId').value.trim();
    if(!id) return;
    Services = Services.filter(x=>x.ServiceID!==id);
    persistAll(); renderServices(); $('#svcForm').reset();
  });

  // --- Inventory ---
  function renderInventory(){
    const list = $('#invList'); list.innerHTML='';
    Inventory.forEach(i=>{
      list.appendChild(renderItem(`${i.ItemID} — ${i.Name} • OnHand ${i.OnHand||0} • ${i.Location||''}`, [
        btn('Edit', ()=>fillInvForm(i))
      ]));
    });
  }
  function fillInvForm(i){
    $('#iId').value=i.ItemID||'';
    $('#iSku').value=i.SKU||'';
    $('#iName').value=i.Name||'';
    $('#iOn').value=i.OnHand||'';
    $('#iRe').value=i.ReorderPoint||'';
    $('#iCost').value=i.UnitCost||'';
    $('#iLoc').value=i.Location||'';
    $('#iNotes').value=i.Notes||'';
  }
  $('#invForm').addEventListener('submit', e=>{
    e.preventDefault();
    const it = {
      ItemID: $('#iId').value.trim(),
      SKU: $('#iSku').value.trim(),
      Name: $('#iName').value.trim(),
      OnHand: Number($('#iOn').value||0),
      ReorderPoint: Number($('#iRe').value||0),
      UnitCost: Number($('#iCost').value||0),
      Location: $('#iLoc').value.trim(),
      Notes: $('#iNotes').value.trim()
    };
    const idx = Inventory.findIndex(x=>x.ItemID===it.ItemID);
    if(idx>=0) Inventory[idx]=it; else Inventory.push(it);
    persistAll(); renderInventory(); e.target.reset();
  });
  $('#iClear').addEventListener('click', ()=>$('#invForm').reset());
  $('#iDelete').addEventListener('click', ()=>{
    const id = $('#iId').value.trim();
    if(!id) return;
    Inventory = Inventory.filter(x=>x.ItemID!==id);
    persistAll(); renderInventory(); $('#invForm').reset();
  });

  // --- Work Orders ---
  function updateSelectors(){
    const cl = $('#woClient'); cl.innerHTML='<option value="">—</option>' + Clients.map(c=>`<option>${c.ClientID}</option>`).join('');
    const tk = $('#woTech'); tk.innerHTML='<option value="">—</option>' + Techs.map(t=>`<option>${t.TechID}</option>`).join('');
    const sv = $('#woService'); sv.innerHTML='<option value="">—</option>' + Services.map(s=>`<option>${s.ServiceID}</option>`).join('');
    const av = $('#avTech'); av.innerHTML = '<option value="">—</option>' + Techs.map(t=>`<option>${t.TechID}</option>`).join('');
  }
  function renderWO(){
    updateSelectors();
    const list = $('#woList'); list.innerHTML='';
    WorkOrders.slice().reverse().forEach(w=>{
      const svc = Services.find(s=>s.ServiceID===w.ServiceID)?.Name||w.ServiceID||'';
      const txt = `${w.WorkOrderID} — ${svc} • ${w.ClientID||''} • ${w.ScheduledStart?new Date(w.ScheduledStart).toLocaleString():''}`;
      const right = [ badge(w.Status), btn('Edit', ()=>fillWOForm(w)) ];
      if(Deposits.find(d=>d.WorkOrderID===w.WorkOrderID && d.Status!=='Paid')){
        right.unshift(badge('Deposit Due'));
      }
      list.appendChild(renderItem(txt, right));
    });
  }
  function fillWOForm(w){
    $('#woId').value = w.WorkOrderID||'';
    $('#woStatus').value = w.Status||'Draft';
    $('#woClient').value = w.ClientID||'';
    $('#woTech').value = w.TechID||'';
    $('#woService').value = w.ServiceID||'';
    $('#woQuoted').value = w.QuotedPrice||'';
    $('#woRequested').value = (w.RequestedDate||'').slice(0,10);
    $('#woStart').value = w.ScheduledStart||'';
    $('#woEnd').value = w.ScheduledEnd||'';
    $('#woHours').value = w.ActualHours||'';
    $('#woLoc').value = w.Location||'';
    $('#woNotes').value = w.Notes||'';
    $('#woHint').textContent='';
  }
  function getWOForm(){
    return {
      WorkOrderID: $('#woId').value.trim(),
      Status: $('#woStatus').value,
      ClientID: $('#woClient').value,
      TechID: $('#woTech').value,
      ServiceID: $('#woService').value,
      QuotedPrice: Number($('#woQuoted').value||0),
      RequestedDate: $('#woRequested').value || null,
      ScheduledStart: $('#woStart').value || null,
      ScheduledEnd: $('#woEnd').value || null,
      ActualHours: Number($('#woHours').value||0),
      Location: $('#woLoc').value.trim(),
      Notes: $('#woNotes').value.trim()
    };
  }
  function within24h(dt){
    if(!dt) return false;
    const t = new Date(dt).getTime();
    const now = Date.now();
    return (t - now) < (24*60*60*1000);
  }
  function techUnavailable(techID, start){
    if(!techID || !start) return false;
    const d = new Date(start);
    const date = d.toISOString().slice(0,10);
    const recs = Availability.filter(a=>a.TechID===techID && a.Date===date && !a.IsAvailable);
    return recs.length>0;
  }
  function ensureDeposit(w){
    const existing = Deposits.find(d=>d.WorkOrderID===w.WorkOrderID);
    if(w.Status==='Scheduled'){
      if(!existing){
        const amount = Math.round((w.QuotedPrice*0.20)*100)/100;
        Deposits.push({DepositID:'D-'+Math.floor(Math.random()*1e6), WorkOrderID:w.WorkOrderID, Amount:amount, Percent:20, Status:'Requested', RequestedOn:new Date().toISOString(), PaidOn:null});
      }else if(existing && existing.Status==='Refunded' || existing.Status==='Waived'){
        // do nothing
      }
    }
  }
  $('#woForm').addEventListener('submit', e=>{
    e.preventDefault();
    const w = getWOForm();
    const hint = $('#woHint');
    // Rules
    if(w.Status==='Completed'){
      const dep = Deposits.find(d=>d.WorkOrderID===w.WorkOrderID);
      if(!dep || dep.Status!=='Paid'){
        hint.textContent = 'Cannot mark Completed: deposit is not Paid.';
        hint.style.color = 'var(--bad)';
        return;
      }
    }
    if(within24h(w.ScheduledStart)){
      const dep = Deposits.find(d=>d.WorkOrderID===w.WorkOrderID);
      if(!dep || dep.Status!=='Paid'){
        hint.textContent = 'Inside 24h: a 20% deposit must be Paid before scheduling.';
        hint.style.color = 'var(--warn)';
        return;
      }
    }
    if(techUnavailable(w.TechID, w.ScheduledStart)){
      hint.textContent = 'Technician has an availability conflict for that day/time.';
      hint.style.color = 'var(--warn)';
      return;
    }
    ensureDeposit(w);
    const i = WorkOrders.findIndex(x=>x.WorkOrderID===w.WorkOrderID);
    if(i>=0) WorkOrders[i]=w; else WorkOrders.push(w);
    persistAll(); renderWO(); renderDeposits(); hint.textContent='Saved'; hint.style.color='var(--muted)';
  });
  $('#woClear').addEventListener('click', ()=>{ $('#woForm').reset(); $('#woHint').textContent=''; });
  $('#woDelete').addEventListener('click', ()=>{
    const id = $('#woId').value.trim(); if(!id) return;
    WorkOrders = WorkOrders.filter(x=>x.WorkOrderID!==id);
    Deposits = Deposits.filter(d=>d.WorkOrderID!==id);
    persistAll(); renderWO(); renderDeposits(); $('#woForm').reset();
  });

  // --- Deposits ---
  function renderDeposits(){
    const list = $('#depList'); list.innerHTML='';
    Deposits.forEach(d=>{
      const wo = WorkOrders.find(w=>w.WorkOrderID===d.WorkOrderID);
      const txt = `${d.DepositID} — WO ${d.WorkOrderID} • ${fmt.format(d.Amount||0)} • ${d.Status}`;
      const actions = [];
      if(d.Status!=='Paid'){
        actions.push(btn('Mark Paid', ()=>{ d.Status='Paid'; d.PaidOn=new Date().toISOString(); persistAll(); renderDeposits(); renderWO(); }));
      }
      actions.push(btn('Open WO', ()=>{ if(wo) { fillWOForm(wo); showSection('workorders'); } }));
      actions.push(btn('Delete', ()=>{ Deposits = Deposits.filter(x=>x.DepositID!==d.DepositID); persistAll(); renderDeposits(); }));
      list.appendChild(renderItem(txt, actions));
    });
  }

  // --- Export/Import ---
  function download(filename, text, type='application/json'){
    const blob = new Blob([text], {type});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = filename; a.click();
    setTimeout(()=>URL.revokeObjectURL(url), 1000);
  }
  function exportJSON(){
    const all = {Clients,Techs,Services,WorkOrders,Deposits,Availability,Inventory};
    download('mbs_logistics_export.json', JSON.stringify(all,null,2));
  }
  function toCSV(rows){
    if(!rows || rows.length===0) return '';
    const keys = Object.keys(rows[0]);
    const esc = v => ('"'+String(v).replace(/"/g,'""')+'"');
    return keys.join(',') + '\n' + rows.map(r=> keys.map(k=> esc(r[k]??'')).join(',')).join('\n');
  }
  function exportCSV(){
    const tables = [
      ['clients.csv', Clients],
      ['technicians.csv', Techs],
      ['services.csv', Services],
      ['work_orders.csv', WorkOrders],
      ['deposits.csv', Deposits],
      ['availability.csv', Availability],
      ['inventory.csv', Inventory],
    ];
    tables.forEach(([name, rows])=>{
      if(rows.length>0) download(name, toCSV(rows), 'text/csv');
    });
  }
  function importJSON(file){
    const r = new FileReader();
    r.onload = () => {
      try{
        const all = JSON.parse(r.result);
        Clients=all.Clients||[]; Techs=all.Techs||[]; Services=all.Services||[]; WorkOrders=all.WorkOrders||[]; Deposits=all.Deposits||[]; Availability=all.Availability||[]; Inventory=all.Inventory||[];
        persistAll(); showSection('dashboard');
      }catch(e){ alert('Invalid JSON'); }
    };
    r.readAsText(file);
  }
  $('#exportAllBtn').addEventListener('click', exportJSON);
  $('#importAllBtn').addEventListener('click', ()=>$('#importFile').click());
  $('#exportJson').addEventListener('click', exportJSON);
  $('#exportCsv').addEventListener('click', exportCSV);
  $('#importFile').addEventListener('change', e=>{ const f=e.target.files[0]; if(f) importJSON(f); });
  $('#resetData').addEventListener('click', ()=>{
    if(confirm('Reset all local data?')){
      Clients=[];Techs=[];Services=[];WorkOrders=[];Deposits=[];Availability=[];Inventory=[];
      persistAll(); location.reload();
    }
  });

  // --- Quick create ---
  $('#quickNewWO').addEventListener('click', ()=>{ $('#woForm').reset(); $('#woId').value='WO-'+Math.floor(Math.random()*1e6); showSection('workorders'); });
  $('#quickNewClient').addEventListener('click', ()=>{ $('#clientForm').reset(); $('#clId').value='CL-'+Math.floor(Math.random()*1e6); showSection('clients'); });

  // --- Install hint (Add to Home Screen) ---
  $('#installHintBtn').addEventListener('click', ()=>{
    alert('On iPad: open this page in Safari → tap the Share icon → “Add to Home Screen”. The app will open full screen and work offline.');
  });

  // Initial renders
  renderDashboard(); renderWO(); renderClients(); renderTechs(); renderServices(); renderDeposits(); renderInventory();

  // --- PWA ---
  if('serviceWorker' in navigator){
    window.addEventListener('load', ()=>{
      navigator.serviceWorker.register('./service-worker.js').catch(console.error);
    });
  }